from typing import List, Any, Dict

from PrePrune.graph.node import Node
from PrePrune.agents.agent_registry import AgentRegistry
from PrePrune.llm.llm_registry import LLMRegistry
from PrePrune.prompt.prompt_set_registry import PromptSetRegistry
from PrePrune.tools.coding.python_executor import PyExecutor


@AgentRegistry.register('CodeWriting')
class CodeWriting(Node):
    def __init__(self, id: str | None = None, role: str = None, domain: str = "", llm_name: str = "", ):
        super().__init__(id, "CodeWriting", domain, llm_name)
        self.llm = LLMRegistry.get(llm_name)
        self.prompt_set = PromptSetRegistry.get(domain)
        self.role = self.prompt_set.get_role() if role is None else role
        self.constraint = self.prompt_set.get_constraint(self.role)

    def _process_inputs(
            self,
            raw_inputs: Dict[str, str],
            spatial_info: Dict[str, Dict],
            temporal_info: Dict[str, Dict],
            **kwargs
    ) -> List[Any]:

        system_prompt = self.constraint
        spatial_str = ""
        temporal_str = ""

        for id, info in spatial_info.items():
            output = info.get("output")

            if not output or not isinstance(output, str):
                spatial_str += (
                    f"Agent {id} as a {info['role']} did not produce a valid output.\n\n"
                )
                continue

            if (
                    output.startswith("```python")
                    and output.endswith("```")
                    and self.role not in ["Normal Programmer", "Stupid Programmer"]
            ):
                code = output.lstrip("```python\n").rstrip("\n```")
                is_solved, feedback, state = PyExecutor().execute(
                    code, self.internal_tests, timeout=10
                )

                if is_solved and len(self.internal_tests):
                    return "is_solved", output

                spatial_str += (
                    f"Agent {id} as a {info['role']}:\n\n"
                    f"The code written by the agent is:\n\n{output}\n\n"
                    f"Whether it passes internal testing? {is_solved}.\n\n"
                    f"The feedback is:\n\n{feedback}.\n\n"
                )
            else:
                spatial_str += (
                    f"Agent {id} as a {info['role']} provides the following info:\n"
                    f"{output}\n\n"
                )

        for id, info in temporal_info.items():
            output = info.get("output")

            if not output or not isinstance(output, str):
                temporal_str += (
                    f"Agent {id} as a {info['role']} did not produce a valid output.\n\n"
                )
                continue

            if (
                    output.startswith("```python")
                    and output.endswith("```")
                    and self.role not in ["Normal Programmer", "Stupid Programmer"]
            ):
                code = output.lstrip("```python\n").rstrip("\n```")
                is_solved, feedback, state = PyExecutor().execute(
                    code, self.internal_tests, timeout=10
                )

                if is_solved and len(self.internal_tests):
                    return "is_solved", output

                temporal_str += (
                    f"Agent {id} as a {info['role']}:\n\n"
                    f"The code written by the agent is:\n\n{output}\n\n"
                    f"Whether it passes internal testing? {is_solved}.\n\n"
                    f"The feedback is:\n\n{feedback}.\n\n"
                )
            else:
                temporal_str += (
                    f"Agent {id} as a {info['role']} provides the following info:\n"
                    f"{output}\n\n"
                )

        user_prompt = f"The task is:\n\n{raw_inputs['task']}\n"

        if spatial_str:
            user_prompt += (
                "At the same time, the outputs and feedbacks of other agents are as follows:\n\n"
                f"{spatial_str}\n\n"
            )

        if temporal_str:
            user_prompt += (
                "In the last round of dialogue, the outputs and feedbacks of some agents were:\n\n"
                f"{temporal_str}"
            )

        return system_prompt, user_prompt

    def extract_example(self, prompt: str) -> list:
        prompt = prompt['task']
        lines = (line.strip() for line in prompt.split('\n') if line.strip())

        results = []
        lines_iter = iter(lines)
        for line in lines_iter:
            if line.startswith('>>>'):
                function_call = line[4:]
                expected_output = next(lines_iter, None)
                if expected_output:
                    results.append(f"assert {function_call} == {expected_output}")

        return results

    def _execute(self, input: Dict[str, str], spatial_info: Dict[str, Any], temporal_info: Dict[str, Any], **kwargs):
        """ To be overriden by the descendant class """
        """ Use the processed input to get the result """
        self.internal_tests = self.extract_example(input)
        system_prompt, user_prompt = self._process_inputs(input, spatial_info, temporal_info)
        message = [{'role': 'system', 'content': system_prompt}, {'role': 'user', 'content': user_prompt}]
        response = self.llm.gen(message)
        return response

    async def _async_execute(self, input: Dict[str, str], spatial_info: Dict[str, Any], temporal_info: Dict[str, Any],
                             **kwargs):
        """ To be overriden by the descendant class """
        """ Use the processed input to get the result """
        """ The input type of this node is Dict """
        self.internal_tests = self.extract_example(input)
        system_prompt, user_prompt = self._process_inputs(input, spatial_info, temporal_info)
        ## test
        if system_prompt == "is_solved":
            return user_prompt
        message = [{'role': 'system', 'content': system_prompt}, {'role': 'user', 'content': user_prompt}]
        response = await self.llm.agen(message)
        # print(f"################system prompt:{system_prompt}")
        # print(f"################user prompt:{user_prompt}")
        # print(f"################response:{response}")
        return response

    def _execute_conclude(self,  input, answer, Knowledge, role, **kwargs):
        """
        Conclude and summarize experience into structured memory (JSON format)
        """

        system_prompt = self.prompt_set.get_description(role)

        import json
        knowledge_schema_str = json.dumps(Knowledge, indent=2, ensure_ascii=False)

        user_prompt = f"""
        ## Task
        You are updating an agent's structured memory.

        Given the current memory (JSON schema) and a new answer,
        refine and update the memory by extracting only the most valuable and generalizable knowledge.

        ## Input
        Question:
        {input}

        Final Answer:
        {answer}

        Current Memory (JSON Schema):
        {knowledge_schema_str}

        ## Instructions
        1. DO NOT change the JSON structure (keys must remain exactly the same).
        2. Update the existing fields using the new answer.
        3. Keep only high-value, reusable knowledge.
        4. REMOVE redundant, duplicate, or low-information content.
        5. Prefer concise and general insights over specific details.
        6. Limit the total number of items in each list (keep it compact).

        ## Output Requirements
        - Output ONLY valid JSON
        - No explanation
        - No extra text
        """

        message = [
            {'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': user_prompt}
        ]

        response = self.llm.gen(message)

        if response == "" or response == "None":
            return Knowledge

        try:
            parsed = json.loads(response)
            return parsed
        except Exception:
            # fallback
            return Knowledge